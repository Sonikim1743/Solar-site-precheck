const POWER_GRID_ENDPOINTS = Object.freeze([
  "https://overpass-api.de/api/interpreter",
  "https://lambert.openstreetmap.de/api/interpreter"
]);
const DEFAULT_RADIUS_METERS = 5e3;
const DEFAULT_TIMEOUT_MS = 45e3;
const CACHE_TTL_MS = 10 * 60 * 1e3;
const FAILURE_COOLDOWN_MS = 5 * 60 * 1e3;
const transportStates = /* @__PURE__ */ new WeakMap();
function buildPowerGridOverpassQuery(lat, lon, radiusMeters = DEFAULT_RADIUS_METERS, options = {}) {
  const radius = Math.max(500, Math.min(5e4, Math.round(radiusMeters)));
  const includeSupports = options.includeSupports !== false;
  const queryLat = Number(lat).toFixed(7);
  const queryLon = Number(lon).toFixed(7);
  return `[out:json][timeout:25];
(
  way(around:${radius},${queryLat},${queryLon})["power"="line"];
  way(around:${radius},${queryLat},${queryLon})["power"="minor_line"];
  node(around:${radius},${queryLat},${queryLon})["power"="substation"];
  way(around:${radius},${queryLat},${queryLon})["power"="substation"];
${includeSupports ? `  node(around:${radius},${queryLat},${queryLon})["power"="tower"];
  node(around:${radius},${queryLat},${queryLon})["power"="pole"];` : ""}
);
out body geom;`;
}
function gridError(code, message, retryable = false) {
  return Object.assign(new Error(message), { code, retryable });
}
function transportState(fetchImpl) {
  if (!transportStates.has(fetchImpl)) {
    transportStates.set(fetchImpl, { cache: /* @__PURE__ */ new Map(), pending: /* @__PURE__ */ new Map(), unavailable: /* @__PURE__ */ new Map(), rateLimitedUntil: 0 });
  }
  return transportStates.get(fetchImpl);
}
async function requestPowerGrid(endpoint, body, fetchImpl, timeoutMs, userAgent) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetchImpl(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8", ...userAgent ? { "User-Agent": userAgent } : {} },
      body,
      signal: controller.signal,
      credentials: "omit"
    });
    if (response.status === 429) {
      const retryAfter = response.headers?.get("Retry-After");
      const seconds = retryAfter ? Number(retryAfter) : NaN;
      const retryAt = Number.isFinite(seconds) ? Date.now() + seconds * 1e3 : Date.parse(retryAfter);
      throw Object.assign(gridError("rate-limit", "公開地図サーバーの利用制限中です。しばらく待ってから再試行してください。"), {
        retryAt: Math.max(Date.now() + 6e4, Number.isFinite(retryAt) ? retryAt : 0)
      });
    }
    if (!response.ok) {
      throw gridError("http", `公開地図サーバーが応答できませんでした（HTTP ${response.status}）。`, response.status >= 500 || response.status === 408);
    }
    const payload = await response.json();
    if (payload?.remark || !Array.isArray(payload?.elements)) {
      throw gridError("invalid-response", "公開地図サーバーから完全な検索結果を取得できませんでした。", true);
    }
    return { elements: payload.elements, sourceEndpoint: payload.sourceEndpoint || endpoint, fetchedAt: payload.fetchedAt || (/* @__PURE__ */ new Date()).toISOString() };
  } catch (error) {
    if (error?.code && typeof error.code === "string") throw error;
    if (controller.signal.aborted || error?.name === "AbortError") {
      throw gridError("timeout", "公開地図データの取得がタイムアウトしました。", true);
    }
    throw gridError("network", "公開地図サーバーに接続できませんでした。", true);
  } finally {
    clearTimeout(timeout);
  }
}
async function fetchPowerGridPayload(lat, lon, radiusMeters, options = {}) {
  const fetchImpl = options.fetchImpl || fetch;
  const state = transportState(fetchImpl);
  const endpoints = options.proxy ? ["/api/power-grid"] : options.endpoint ? [options.endpoint] : POWER_GRID_ENDPOINTS;
  const query = buildPowerGridOverpassQuery(lat, lon, radiusMeters, options);
  const body = options.proxy ? new URLSearchParams({ lat: String(lat), lon: String(lon), radius: String(radiusMeters), supports: options.includeSupports === false ? "0" : "1" }).toString() : new URLSearchParams({ data: query }).toString();
  const key = JSON.stringify([endpoints, query, options.userAgent || ""]);
  const cached = state.cache.get(key);
  if (options.cache !== false && cached?.expiresAt > Date.now()) {
    options.onProgress?.({ type: "cache", radiusMeters });
    return { ...cached.data, cached: true };
  }
  if (cached) state.cache.delete(key);
  if (!state.pending.has(key)) {
    const pending2 = (async () => {
      if (state.rateLimitedUntil > Date.now()) {
        throw gridError("rate-limit", "公開地図サーバーの利用制限中です。しばらく待ってから再試行してください。");
      }
      let lastError;
      for (const [index, endpoint] of endpoints.entries()) {
        const unavailable = state.unavailable.get(endpoint);
        if (unavailable?.until > Date.now()) {
          lastError = unavailable.error;
          continue;
        }
        options.onProgress?.({ type: index ? "fallback" : "request", radiusMeters });
        try {
          const data = await requestPowerGrid(endpoint, body, fetchImpl, options.timeoutMs || (options.proxy ? 1e5 : DEFAULT_TIMEOUT_MS), options.userAgent);
          state.unavailable.delete(endpoint);
          if (options.cache !== false) {
            for (const [cacheKey, entry] of state.cache) {
              if (entry.expiresAt <= Date.now()) state.cache.delete(cacheKey);
            }
            if (state.cache.size >= 8) state.cache.delete(state.cache.keys().next().value);
            state.cache.set(key, { data, expiresAt: Date.now() + CACHE_TTL_MS });
          }
          return data;
        } catch (error) {
          if (error.code === "rate-limit") state.rateLimitedUntil = error.retryAt;
          if (!error.retryable) throw error;
          lastError = error;
          state.unavailable.set(endpoint, { until: Date.now() + FAILURE_COOLDOWN_MS, error });
        }
      }
      throw gridError(lastError?.code || "network", `${lastError?.message || "公開地図サーバーに接続できませんでした。"} 時間をおいて再試行してください。読込済みの公開空容量DBは引き続き確認できます。`);
    })();
    state.pending.set(key, pending2);
  }
  const pending = state.pending.get(key);
  try {
    const data = await pending;
    return { ...data, cached: false };
  } finally {
    if (state.pending.get(key) === pending) state.pending.delete(key);
  }
}
const POWER_GRID_USER_AGENT = "SolarSitePrecheck/1.23 (https://github.com/Sonikim1743/Solar-site-precheck)";
const allowedFields = /* @__PURE__ */ new Set(["lat", "lon", "radius", "supports"]);
let activeRequests = 0;
function json(payload, status = 200, extra = {}) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", ...extra }
  });
}
async function handlePowerGridRequest(request, options = {}) {
  if (request.method !== "POST") return json({ error: "POST required" }, 405, { Allow: "POST" });
  const origin = request.headers.get("Origin");
  if (origin && origin !== new URL(request.url).origin) return json({ error: "Same-origin requests only" }, 403);
  if (!request.headers.get("Content-Type")?.startsWith("application/x-www-form-urlencoded")) return json({ error: "Invalid content type" }, 415);
  let body = "";
  const reader = request.body?.getReader();
  if (reader) {
    const decoder = new TextDecoder();
    let size = 0;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > 512) {
        await reader.cancel();
        return json({ error: "Request too large" }, 413);
      }
      body += decoder.decode(value, { stream: true });
    }
  }
  const params = new URLSearchParams(body);
  if ([...params.keys()].some((key) => !allowedFields.has(key) || params.getAll(key).length !== 1)) return json({ error: "Invalid parameters" }, 400);
  const values = ["lat", "lon", "radius"].map((key) => params.get(key)?.trim());
  const [lat, lon, radiusMeters] = values.map(Number);
  if (values.some((value) => !value) || ![lat, lon, radiusMeters].every(Number.isFinite) || lat < 20 || lat > 46 || lon < 122 || lon > 154 || !Number.isInteger(radiusMeters) || radiusMeters < 500 || radiusMeters > 5e4 || !["0", "1"].includes(params.get("supports"))) return json({ error: "Invalid Japan coordinates or radius" }, 400);
  if (activeRequests >= 4) return json({ error: "Busy; retry later" }, 429, { "Retry-After": "60" });
  activeRequests++;
  try {
    const data = await fetchPowerGridPayload(lat, lon, radiusMeters, {
      fetchImpl: options.fetchImpl,
      timeoutMs: options.timeoutMs,
      includeSupports: params.get("supports") === "1",
      userAgent: POWER_GRID_USER_AGENT
    });
    return json(data);
  } catch (error) {
    return json(
      { error: error.message || "公開地図データを取得できませんでした。" },
      error.code === "rate-limit" ? 429 : 502,
      error.code === "rate-limit" ? { "Retry-After": String(Math.max(60, Math.ceil(((error.retryAt || Date.now() + 6e4) - Date.now()) / 1e3))) } : {}
    );
  } finally {
    activeRequests--;
  }
}
async function powerGridMiddleware(request, response, next) {
  if (new URL(request.url || "/", "http://localhost").pathname !== "/api/power-grid") return next();
  try {
    const chunks = [];
    let size = 0;
    for await (const chunk of request) {
      size += chunk.length;
      if (size > 512) {
        response.writeHead(413, { "Content-Type": "application/json" });
        response.end(JSON.stringify({ error: "Request too large" }));
        return;
      }
      chunks.push(chunk);
    }
    const result = await handlePowerGridRequest(new Request(`http://${request.headers.host}${request.url}`, {
      method: request.method,
      headers: request.headers,
      ...["GET", "HEAD"].includes(request.method) ? {} : { body: Buffer.concat(chunks) }
    }));
    response.writeHead(result.status, Object.fromEntries(result.headers));
    response.end(await result.text());
  } catch {
    response.writeHead(502, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
    response.end(JSON.stringify({ error: "公開地図データを取得できませんでした。" }));
  }
}
export {
  powerGridMiddleware
};
