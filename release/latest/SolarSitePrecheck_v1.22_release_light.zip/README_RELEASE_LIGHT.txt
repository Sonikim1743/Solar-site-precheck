﻿Solar Site Precheck Release Light

This package is for online update distribution.
It does not include node.exe, source code, node_modules, Service Worker, or internal .spt templates.
It includes Cloudflare Pages helper files: functions\api, wrangler.pages.toml, cloudflare-portable-guide.html.

Existing desktop installations should keep their runtime\node.exe or installed Node.js.

To update this app later, run UPDATE_APP_FROM_RELEASE.cmd.
